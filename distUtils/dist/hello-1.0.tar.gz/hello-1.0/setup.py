from distutils.core import setup


setup(name='hello',version='1.0',description='A simple example',author='Cliicy Luo',py_modules=['hello'])
